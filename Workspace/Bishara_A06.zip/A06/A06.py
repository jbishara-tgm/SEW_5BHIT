import threading
from time import *

threads = 3
def section():
    """
    Weißt den Zahlen den Threads zu
    :return: Eine Liste mit den Zahlen in einer Liste für die Threads
    """
    hilfe = []
    section_liste = []

    for i in range(text):
        hilfe.append(i)
        hilfe[i] = i+1

    for i in range(threads):
        section_liste.append(hilfe[i::threads])
    return section_liste



class Summe(threading.Thread):
    counter = 0
    lock = threading.Lock()

    def __init__(self,teil):
        """
        Konstruktor der Klasse
        :param teil: Liste die man durch section erhalten hat
        """
        threading.Thread.__init__(self)
        self.__teil = teil

    def run(self):
        """
        Summiert die Zahlen hoch
        :return: void
        """
        for i in self.__teil:
             with Summe.lock:
                Summe.counter += i


text = input("Bitte die gew. Zahl eingeben!")
text = int(text)
sectionL = section()
threadsL = []
for i in range(threads):
    thread = Summe(sectionL[i])
    threadsL.append(thread)
    threadsL[i].start()

for i in range(len(threadsL)):
    t1 = clock()
    threadsL[i].join()
t2 = clock()
dt = t2 - t1
print(Summe.counter)
print(dt)