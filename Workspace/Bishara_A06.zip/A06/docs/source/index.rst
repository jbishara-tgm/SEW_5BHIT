.. A06 documentation master file, created by
   sphinx-quickstart on Sun Nov 13 22:19:15 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to A06's documentation!
===============================


Autor: Johannes Bishara

Datum: 13.11.2016

Zweck: Das Programm summiert die Zahlen von 1 bis eingegebener User-Input auf und gibt das Ergebnis aus. Zeitmessung vorhanden.
Contents:

.. toctree::
   :maxdepth: 2

   code

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

