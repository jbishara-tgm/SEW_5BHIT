import threading
from random import randint

class Main(threading.Thread):
    counter = 0
    lock = threading.Lock()

    def __init__(self, x):
        threading.Thread.__init__(self)
        self.__x = x
        self.__y = 0

    def run(self):
        self.__y += 1

        bew = 0
        bew = randint(1,3)
        if(bew == 1):
            self.__x += 1
        if(bew == 2):
            self.__x += -1
        if(bew == 3):
            self.__x = self.__x

        for x in range(self.__x):
            print(" ", end='')
            